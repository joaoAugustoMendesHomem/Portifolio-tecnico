# Unsmoke

![logo](https://user-images.githubusercontent.com/79464636/175755491-0635d6d2-d6e9-401f-8e13-58cd8a98107e.png)
> Status: Developing
### Unsmoke is app for cigarette, pod, vaper and hookah users. The app helps you to: 
* see the effects of these drugs in your body 
* helps you stop using these drugs
* count how many times you've used it

### Technologies used
<table>
  <tr>
    <td> JDK </td>
    <td> Android Studio </td>
    <td> Firebase </td>
  </tr>
  <tr>
    <td> 18.0.1.1 </td>
    <td> 2021.2.1 </td>
    <td> 30.1.0 </td>
  </tr>
